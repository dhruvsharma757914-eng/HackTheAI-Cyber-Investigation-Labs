import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { AuthForm } from "@/components/AuthForm";

export const metadata = { title: "Sign in // VT-SOC" };

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect("/");

  return <AuthForm mode="login" />;
}
